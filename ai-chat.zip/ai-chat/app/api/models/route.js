import { NextResponse } from "next/server";

// Ambil daftar model yang masih aktif langsung dari Groq
export async function POST(req) {
  try {
    const { apiKey } = await req.json();
    if (!apiKey) return NextResponse.json({ ok: false, message: "API key kosong" }, { status: 400 });

    const res = await fetch("https://api.groq.com/openai/v1/models", {
      headers: { Authorization: `Bearer ${apiKey}` },
    });
    if (!res.ok) return NextResponse.json({ ok: false, message: await res.text() }, { status: res.status });

    const data = await res.json();
    const skip = /whisper|tts|guard|orpheus|safeguard|embed/i;
    const models = (data.data || []).map((m) => m.id).filter((id) => id && !skip.test(id)).sort();
    return NextResponse.json({ ok: true, models });
  } catch (e) {
    return NextResponse.json({ ok: false, message: e.message }, { status: 500 });
  }
}
