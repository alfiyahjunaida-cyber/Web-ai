"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import {
  Plus, Settings as Cog, Sun, Moon, Send, Square, Copy, Check, RefreshCw,
  Menu, X, Eye, EyeOff, Trash2, Sparkles, Download, Home,
} from "lucide-react";

const DEFAULT_MODELS = ["openai/gpt-oss-120b", "openai/gpt-oss-20b", "qwen/qwen3.6-27b"];
const DEFAULTS = {
  apiKey: "",
  model: DEFAULT_MODELS[0],
  systemPrompt: "Kamu adalah AI asisten yang ramah.",
  temperature: 0.7,
  maxTokens: 1024,
  models: DEFAULT_MODELS,
};

const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
const load = (k, f) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : f; } catch { return f; } };
const save = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} };
const niceError = (msg) => { try { return JSON.parse(msg)?.error?.message || msg; } catch { return msg; } };

export default function ChatPage() {
  const [ready, setReady] = useState(false);
  const [settings, setSettings] = useState(DEFAULTS);
  const [chats, setChats] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [sideOpen, setSideOpen] = useState(false);
  const [setOpen, setSetOpen] = useState(false);
  const [dark, setDark] = useState(true);
  const [copied, setCopied] = useState("");
  const abortRef = useRef(null);
  const bottomRef = useRef(null);
  const taRef = useRef(null);

  /* ---------- Muat & simpan data di localStorage ---------- */
  useEffect(() => {
    setSettings({ ...DEFAULTS, ...load("aichat_settings", {}) });
    setChats(load("aichat_chats", []));
    setActiveId(load("aichat_active", null));
    setDark(document.documentElement.classList.contains("dark"));
    setReady(true);
  }, []);
  useEffect(() => { if (ready) save("aichat_settings", settings); }, [settings, ready]);
  useEffect(() => { if (ready) save("aichat_chats", chats); }, [chats, ready]);
  useEffect(() => { if (ready) save("aichat_active", activeId); }, [activeId, ready]);

  const active = chats.find((c) => c.id === activeId);
  const messages = active?.messages || [];

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages.length, loading, activeId]);

  const patch = (id, fn) => setChats((p) => p.map((c) => (c.id === id ? fn(c) : c)));

  function toggleTheme() {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle("dark", next);
    try { localStorage.setItem("aichat_theme", next ? "dark" : "light"); } catch {}
  }

  function newChat() {
    setActiveId(null);
    setError("");
    setSideOpen(false);
  }

  function deleteChat(id) {
    setChats((p) => p.filter((c) => c.id !== id));
    if (id === activeId) setActiveId(null);
  }

  /* ---------- Kirim ke API ---------- */
  async function ask(history, chatId) {
    if (!settings.apiKey) {
      setError("API key belum diisi. Buka Setting untuk memasukkannya.");
      setSetOpen(true);
      return;
    }
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        signal: ctrl.signal,
        body: JSON.stringify({
          messages: history.map(({ role, content }) => ({ role, content })),
          model: settings.model,
          apiKey: settings.apiKey,
          temperature: settings.temperature,
          max_tokens: settings.maxTokens,
          systemPrompt: settings.systemPrompt,
        }),
      });
      const d = await res.json();
      if (!d.ok) throw new Error(niceError(d.message || "Permintaan gagal"));
      patch(chatId, (c) => ({
        ...c,
        messages: [...history, { id: uid(), role: "assistant", content: d.reply || "(jawaban kosong)" }],
        updated: Date.now(),
      }));
    } catch (e) {
      if (e.name !== "AbortError") setError(e.message);
    } finally {
      setLoading(false);
      abortRef.current = null;
    }
  }

  function send() {
    const text = input.trim();
    if (!text || loading) return;
    const userMsg = { id: uid(), role: "user", content: text };
    let id = activeId;
    let history;
    if (!active) {
      id = uid();
      history = [userMsg];
      setChats((p) => [{ id, title: text.slice(0, 40), messages: history, updated: Date.now() }, ...p]);
      setActiveId(id);
    } else {
      history = [...active.messages, userMsg];
      patch(id, (c) => ({ ...c, messages: history, updated: Date.now() }));
    }
    setInput("");
    if (taRef.current) taRef.current.style.height = "auto";
    ask(history, id);
  }

  function regenerate() {
    if (!active || loading) return;
    const last = messages[messages.length - 1];
    const history = last?.role === "assistant" ? messages.slice(0, -1) : messages;
    if (!history.length) return;
    patch(active.id, (c) => ({ ...c, messages: history }));
    ask(history, active.id);
  }

  const stop = () => abortRef.current?.abort();

  async function copy(id, text) {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const t = document.createElement("textarea");
      t.value = text; document.body.appendChild(t); t.select();
      try { document.execCommand("copy"); } catch {}
      document.body.removeChild(t);
    }
    setCopied(id);
    setTimeout(() => setCopied(""), 1400);
  }

  function onKeyDown(e) {
    if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) {
      e.preventDefault();
      send();
    }
  }

  function onInput(e) {
    setInput(e.target.value);
    e.target.style.height = "auto";
    e.target.style.height = Math.min(e.target.scrollHeight, 180) + "px";
  }

  const modelList = settings.models.includes(settings.model) ? settings.models : [settings.model, ...settings.models];
  const sorted = [...chats].sort((a, b) => b.updated - a.updated);
  const lastIsAssistant = messages[messages.length - 1]?.role === "assistant";

  return (
    <div className="flex h-[100dvh] overflow-hidden">
      {/* Overlay mobile */}
      {sideOpen && <div className="fixed inset-0 z-30 bg-black/60 md:hidden" onClick={() => setSideOpen(false)} />}

      {/* Sidebar */}
      <aside className={`fixed inset-y-0 left-0 z-40 flex w-72 flex-col border-r border-zinc-200 bg-white transition-transform dark:border-zinc-800 dark:bg-[#0f1218] md:static md:translate-x-0 ${sideOpen ? "translate-x-0" : "-translate-x-full"}`}>
        <div className="flex items-center justify-between p-3">
          <Link href="/" className="flex items-center gap-2 font-display font-bold">
            <span className="grid h-7 w-7 place-items-center rounded-lg bg-orange-500 text-white"><Sparkles size={15} /></span>
            AI Chat
          </Link>
          <button className="rounded-lg p-2 hover:bg-zinc-100 dark:hover:bg-zinc-800 md:hidden" onClick={() => setSideOpen(false)} aria-label="Tutup menu"><X size={18} /></button>
        </div>
        <div className="px-3">
          <button onClick={newChat} className="flex w-full items-center justify-center gap-2 rounded-xl bg-orange-500 py-2.5 text-sm font-semibold text-white hover:bg-orange-400">
            <Plus size={17} /> New Chat
          </button>
        </div>
        <p className="px-4 pb-1 pt-4 text-xs font-medium text-zinc-500">History</p>
        <nav className="scroll-thin min-h-0 flex-1 overflow-y-auto px-2 pb-2">
          {sorted.length === 0 && <p className="px-2 py-3 text-sm text-zinc-500">Belum ada riwayat.</p>}
          {sorted.map((c) => (
            <div key={c.id} className={`group flex items-center rounded-lg ${c.id === activeId ? "bg-zinc-100 dark:bg-zinc-800" : "hover:bg-zinc-100 dark:hover:bg-zinc-800/60"}`}>
              <button className="min-w-0 flex-1 truncate px-3 py-2.5 text-left text-sm" onClick={() => { setActiveId(c.id); setError(""); setSideOpen(false); }}>
                {c.title || "Chat baru"}
              </button>
              <button className="mr-1 rounded-md p-1.5 text-zinc-500 hover:text-red-400" onClick={() => deleteChat(c.id)} aria-label="Hapus chat"><Trash2 size={15} /></button>
            </div>
          ))}
        </nav>
        <div className="grid grid-cols-2 gap-2 border-t border-zinc-200 p-3 dark:border-zinc-800">
          <button onClick={() => { setSetOpen(true); setSideOpen(false); }} className="flex items-center justify-center gap-2 rounded-lg border border-zinc-300 py-2 text-sm hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800"><Cog size={16} /> Settings</button>
          <button onClick={toggleTheme} className="flex items-center justify-center gap-2 rounded-lg border border-zinc-300 py-2 text-sm hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800">
            {dark ? <Sun size={16} /> : <Moon size={16} />} {dark ? "Terang" : "Gelap"}
          </button>
        </div>
      </aside>

      {/* Main */}
      <section className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center gap-2 border-b border-zinc-200 px-3 py-2.5 dark:border-zinc-800">
          <button className="rounded-lg p-2 hover:bg-zinc-100 dark:hover:bg-zinc-800 md:hidden" onClick={() => setSideOpen(true)} aria-label="Buka menu"><Menu size={20} /></button>
          <h1 className="min-w-0 flex-1 truncate font-display font-bold">{active?.title || "Chat baru"}</h1>
          <select
            value={settings.model}
            onChange={(e) => setSettings({ ...settings, model: e.target.value })}
            className="max-w-[46%] truncate rounded-lg border border-zinc-300 bg-transparent px-2 py-1.5 text-xs dark:border-zinc-700 dark:bg-[#12151c] sm:max-w-xs sm:text-sm"
            aria-label="Pilih model"
          >
            {modelList.map((m) => <option key={m} value={m}>{m}</option>)}
          </select>
        </header>

        <div className="scroll-thin min-h-0 flex-1 overflow-y-auto">
          <div className="mx-auto max-w-3xl px-4 py-5">
            {messages.length === 0 && !loading && (
              <div className="mt-16 text-center sm:mt-24">
                <span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-orange-500 text-white"><Sparkles size={24} /></span>
                <h2 className="mt-4 font-display text-2xl font-bold">Mau ngobrol apa hari ini?</h2>
                <p className="mt-1 text-sm text-zinc-500">Tulis pesan di bawah untuk mulai.</p>
              </div>
            )}

            {messages.map((m) =>
              m.role === "user" ? (
                <div key={m.id} className="my-4 flex justify-end">
                  <div className="max-w-[85%] whitespace-pre-wrap break-words rounded-2xl rounded-br-md bg-orange-500 px-4 py-2.5 text-white">{m.content}</div>
                </div>
              ) : (
                <div key={m.id} className="my-4 flex justify-start">
                  <div className="min-w-0 max-w-[92%]">
                    <div className="md break-words rounded-2xl rounded-bl-md border border-zinc-200 bg-white px-4 py-2.5 dark:border-zinc-800 dark:bg-[#12151c]">
                      <ReactMarkdown remarkPlugins={[remarkGfm]}>{m.content}</ReactMarkdown>
                    </div>
                    <div className="mt-1.5 flex gap-1 pl-1">
                      <button onClick={() => copy(m.id, m.content)} className="flex items-center gap-1 rounded-md px-2 py-1 text-xs text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-800">
                        {copied === m.id ? <Check size={14} /> : <Copy size={14} />} {copied === m.id ? "Tersalin" : "Copy"}
                      </button>
                    </div>
                  </div>
                </div>
              )
            )}

            {loading && (
              <div className="my-4 flex justify-start">
                <div className="dots flex items-center gap-1.5 rounded-2xl rounded-bl-md border border-zinc-200 bg-white px-4 py-3.5 text-zinc-500 dark:border-zinc-800 dark:bg-[#12151c]" aria-label="AI sedang mengetik">
                  <span /><span /><span />
                </div>
              </div>
            )}

            {error && (
              <div className="my-4 rounded-xl border border-red-500/40 bg-red-500/10 px-4 py-3 text-sm text-red-500 dark:text-red-300">
                {error}
                {messages.length > 0 && !loading && (
                  <button onClick={regenerate} className="ml-2 underline">Coba lagi</button>
                )}
              </div>
            )}

            {lastIsAssistant && !loading && (
              <div className="flex justify-start">
                <button onClick={regenerate} className="flex items-center gap-1.5 rounded-lg border border-zinc-300 px-3 py-1.5 text-xs hover:bg-zinc-100 dark:border-zinc-700 dark:hover:bg-zinc-800">
                  <RefreshCw size={14} /> Regenerate
                </button>
              </div>
            )}
            <div ref={bottomRef} />
          </div>
        </div>

        {/* Input */}
        <div className="border-t border-zinc-200 px-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-3 dark:border-zinc-800">
          <div className="mx-auto flex max-w-3xl items-end gap-2 rounded-2xl border border-zinc-300 bg-white p-2 focus-within:border-orange-500 dark:border-zinc-700 dark:bg-[#12151c]">
            <textarea
              ref={taRef}
              rows={1}
              value={input}
              onChange={onInput}
              onKeyDown={onKeyDown}
              placeholder="Tulis pesan... (Enter kirim, Shift+Enter baris baru)"
              className="max-h-[180px] min-h-[40px] flex-1 resize-none bg-transparent px-2 py-2 text-base outline-none placeholder:text-zinc-500"
            />
            {loading ? (
              <button onClick={stop} className="grid h-10 w-10 flex-none place-items-center rounded-xl bg-zinc-800 text-white dark:bg-zinc-200 dark:text-zinc-900" aria-label="Stop"><Square size={16} fill="currentColor" /></button>
            ) : (
              <button onClick={send} disabled={!input.trim()} className="grid h-10 w-10 flex-none place-items-center rounded-xl bg-orange-500 text-white transition hover:bg-orange-400 disabled:opacity-40" aria-label="Kirim"><Send size={18} /></button>
            )}
          </div>
        </div>
      </section>

      {setOpen && (
        <SettingsPanel
          settings={settings}
          onClose={() => setSetOpen(false)}
          onSave={(s) => { setSettings(s); setError(""); }}
        />
      )}
    </div>
  );
}

/* ================= Panel Setting ================= */
function SettingsPanel({ settings, onClose, onSave }) {
  const [d, setD] = useState(settings);
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState("");
  const [status, setStatus] = useState(null);
  const up = (k, v) => setD((p) => ({ ...p, [k]: v }));

  async function loadModels() {
    if (!d.apiKey) return setStatus({ ok: false, text: "Isi API key dulu." });
    setBusy("models");
    setStatus(null);
    try {
      const r = await fetch("/api/models", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ apiKey: d.apiKey }) });
      const j = await r.json();
      if (!j.ok) throw new Error(niceError(j.message));
      setD((p) => ({ ...p, models: j.models, model: j.models.includes(p.model) ? p.model : j.models[0] || p.model }));
      setStatus({ ok: true, text: `${j.models.length} model dimuat dari Groq.` });
    } catch (e) {
      setStatus({ ok: false, text: e.message });
    } finally { setBusy(""); }
  }

  async function saveAndTest() {
    if (!d.apiKey) return setStatus({ ok: false, text: "API key kosong." });
    setBusy("test");
    setStatus(null);
    try {
      const r = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ apiKey: d.apiKey, model: d.model, messages: [{ role: "user", content: "Balas dengan satu kata: OK" }], max_tokens: 64, temperature: 0 }),
      });
      const j = await r.json();
      if (!j.ok) throw new Error(niceError(j.message));
      onSave({ ...d, apiKey: d.apiKey.trim() });
      setStatus({ ok: true, text: "API key valid dan tersimpan." });
    } catch (e) {
      onSave({ ...d, apiKey: d.apiKey.trim() });
      setStatus({ ok: false, text: "Tersimpan, tapi tes gagal: " + e.message });
    } finally { setBusy(""); }
  }

  const field = "w-full rounded-xl border border-zinc-300 bg-transparent px-3 py-2.5 text-sm outline-none focus:border-orange-500 dark:border-zinc-700";
  const models = d.models.includes(d.model) ? d.models : [d.model, ...d.models];

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 sm:items-center" onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} className="scroll-thin max-h-[92dvh] w-full max-w-lg overflow-y-auto rounded-t-3xl bg-white p-5 dark:bg-[#12151c] sm:rounded-3xl">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-xl font-bold">Settings</h2>
          <button onClick={onClose} className="rounded-lg p-2 hover:bg-zinc-100 dark:hover:bg-zinc-800" aria-label="Tutup"><X size={18} /></button>
        </div>

        <label className="mt-4 block text-sm font-medium">Groq API key</label>
        <div className="relative mt-1.5">
          <input type={show ? "text" : "password"} value={d.apiKey} onChange={(e) => up("apiKey", e.target.value)} placeholder="gsk_..." autoComplete="off" className={field + " pr-11"} />
          <button type="button" onClick={() => setShow(!show)} className="absolute right-2 top-1/2 -translate-y-1/2 rounded-md p-1.5 text-zinc-500" aria-label="Tampilkan key">{show ? <EyeOff size={17} /> : <Eye size={17} />}</button>
        </div>
        <p className="mt-1 text-xs text-zinc-500">Disimpan hanya di browser ini (localStorage).</p>

        <div className="mt-4 flex items-center justify-between">
          <label className="text-sm font-medium">Model</label>
          <button onClick={loadModels} disabled={busy === "models"} className="flex items-center gap-1 text-xs text-orange-500 disabled:opacity-50"><Download size={13} /> {busy === "models" ? "Memuat..." : "Muat daftar dari Groq"}</button>
        </div>
        <select value={d.model} onChange={(e) => up("model", e.target.value)} className={field + " mt-1.5 dark:bg-[#12151c]"}>
          {models.map((m) => <option key={m} value={m}>{m}</option>)}
        </select>
        <input value={d.model} onChange={(e) => up("model", e.target.value.trim())} placeholder="atau ketik ID model sendiri" className={field + " mt-2"} />

        <label className="mt-4 block text-sm font-medium">System prompt</label>
        <textarea rows={3} value={d.systemPrompt} onChange={(e) => up("systemPrompt", e.target.value)} className={field + " mt-1.5 resize-y"} />

        <div className="mt-4 flex items-center justify-between text-sm">
          <label className="font-medium">Temperature</label><span className="text-zinc-500">{Number(d.temperature).toFixed(2)}</span>
        </div>
        <input type="range" min="0" max="1" step="0.05" value={d.temperature} onChange={(e) => up("temperature", parseFloat(e.target.value))} className="mt-1 w-full accent-orange-500" />

        <label className="mt-4 block text-sm font-medium">Max tokens</label>
        <input type="number" min="16" max="32768" value={d.maxTokens} onChange={(e) => up("maxTokens", Math.max(16, parseInt(e.target.value || "1024", 10)))} className={field + " mt-1.5"} />

        {status && (
          <p className={`mt-4 rounded-xl px-3 py-2.5 text-sm ${status.ok ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-300" : "bg-red-500/10 text-red-500 dark:text-red-300"}`}>{status.text}</p>
        )}

        <button onClick={saveAndTest} disabled={busy === "test"} className="mt-5 w-full rounded-xl bg-orange-500 py-3 font-semibold text-white hover:bg-orange-400 disabled:opacity-60">
          {busy === "test" ? "Menguji..." : "Save & Test API Key"}
        </button>
      </div>
    </div>
  );
}
